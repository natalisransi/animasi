from tkinter import *
import time
import math


class bola(object):

     Lebar = 500
     Tinggi = 600

     posX = 50
     posY = 150
     
     def __init__(self):

        
        self.root = Tk()
        self.canvas = Canvas(self.root, width=self.Lebar, height = self.Tinggi)
        self.canvas.pack()
        self.bola1 = self.canvas.create_oval(40, 140, 80, 180, outline='white', fill='green')
        self.bola2 = self.canvas.create_oval(self.posX+0, self.posY+0, self.posX+40, self.posY+40, outline='white', fill='orange')
        self.canvas.pack()
        self.root.after(0, self.animation)
        self.root.mainloop()
        

     def animation(self):
        s=1
        x = -15.4
        xhasil = 0.8
        y = 40
        m=0
        coba=0

        x2 = -15.4
        x2hasil = 0.9
        y2 = 0
        
        jalan = True
        while jalan:
            if m <= 521:
               m=m+1
            
            ylama = y
            y = x*x  - 10*x + 16
               
            yhasil = y - ylama
            x = x + xhasil
            
            y2lama = y2
            y2 = x2*x2  - 10*x2 + 16
               
            y2hasil = y2 - y2lama
            x2 = x2 + x2hasil 
            
            time.sleep(0.015)
            self.canvas.move(self.bola1, xhasil*s, yhasil)
            self.canvas.move(self.bola2, x2hasil*s, y2hasil)
            self.canvas.update()

            if y == 0:
                print (str(xhasil)+" "+str(yhasil)+"hoax")
                
                coba = coba +1
                
            else:
                print ("Coba : "+str(coba)+" - y : "+str(y)+" - x : "+str(x)+" M= "+str(m)+" S= "+str(s))
                #print str(x)+" "+str(y)+"    "+str(x)+" "+str(y)

            if coba == 2:
                jalan = False

            if y + 40 >= self.Tinggi - self.posY:
                x = -15.4

            if y + 40 >= self.Tinggi - self.posY:
                x2 = -15.4

            if m >= 521:
                s=-1
                

            #if y2 + 40 >= self.Tinggi - self.posY:
              #  x2 = -15.4


bola()
